/**
 * Custom index for the extension attention this file should be not delete!
 * It is use as main file but this can be empty by default only need to exits.
 *
 * A project index.js should contain default exports like:
 * export { default } from './components/main';
 */
